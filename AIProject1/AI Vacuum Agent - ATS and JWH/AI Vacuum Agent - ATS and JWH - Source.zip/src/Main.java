import agent.*;
import agent_with_state.AgentWithState;
import environment.*;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.FileReader;
import java.io.BufferedReader;
import java.util.ArrayList;

public class Main {

	public static void main(String[] args) {

		ArrayList<String[]> rawLocData = readFile("initial_condition.txt");
		
		int agentRow = Integer.parseInt(rawLocData.get(0)[0]);
		int agentCol = Integer.parseInt(rawLocData.get(0)[1]);
		int[][] locData = new int[rawLocData.size() - 1][rawLocData.get(1).length];
		
		for (int i = 1; i < rawLocData.size(); ++i) {
			for (int j = 0; j < rawLocData.get(i).length; ++j) {
				locData[i-1][j] = Integer.parseInt(rawLocData.get(i)[j].trim());
			}
		}


		Environment testE = new Environment();
		testE.loadLocData(locData);
		testE.loadAgent(agentRow, agentCol, null);
		testE.print();

		double stateScore = 0.0;
		double srandScore = 0.0;
		double prandScore = 0.0;


		double runs = 5000.0;

		System.out.printf("\nRunning %d trials...\n", (int) runs);
		for (int i = 0; i < runs; ++i) {
			Agent srand = new SemiRandomAgent();
			Agent aws = new AgentWithState();
			Agent prand = new RandomAgent();

			Environment srandEnvr = new Environment();
			srandEnvr.loadLocData(locData);
			srandEnvr.loadAgent(agentRow, agentCol, srand);

			Environment prandEnvr = new Environment();
			prandEnvr.loadLocData(locData);
			prandEnvr.loadAgent(agentRow, agentCol, prand);

			Environment stateEnvr = new Environment();
			stateEnvr.loadLocData(locData);
			stateEnvr.loadAgent(agentRow, agentCol, aws);


			// AWS
			while (aws.lifeRemaining() > 0) {
				stateEnvr.update();
			}
			stateScore += ((double) stateEnvr.reportAgentScore());

			// SRAND
			while (srand.lifeRemaining() > 0) {
				srandEnvr.update();
			}
			srandScore += ((double) srandEnvr.reportAgentScore());

			// PRAND
			while (prand.lifeRemaining() > 0) {
				prandEnvr.update();
			}
			prandScore += ((double) prandEnvr.reportAgentScore());
		}
		stateScore /= runs;
		srandScore /= runs;
		prandScore /= runs;

		System.out.println();
		System.out.printf("Average scores after %d trials: \n", (int) runs);
		System.out.println("   Agent With State:  " + (int) stateScore);
		System.out.println("   Semi Random Agent: " + (int) srandScore);
		System.out.println("   Pure Random Agent: " + (int) prandScore);
	}

	private static ArrayList<String[]> readFile(String filename) {
		ArrayList<String[]> rawLocData = new ArrayList<String[]>();

		try {
			FileReader fr = new FileReader("initial_condition.txt");
			BufferedReader bufferedReader = new BufferedReader(fr);

			String line;
			while((line = bufferedReader.readLine()) != null) {
				rawLocData.add(line.split(","));
			}

			bufferedReader.close();
		}
		catch(FileNotFoundException ex) {
			System.out.println("Unable to open file");
			ex.printStackTrace();
		}
		catch(IOException ex) {
			System.out.println("Error reading file");
			ex.printStackTrace();
		}


		return rawLocData;
	}
}

package environment;

public enum State {
	CLEAN,
	DIRTY,
	BLOCKED,
	UNKNOWN
}
package environment;

public class Location {

	private State state;
	private int row;
	private int col;
	private boolean blocked;
	
	public Location(int row, int col, State state) {
		this.row = row;
		this.col = col;
		this.state = state;
		this.blocked = false;
	}
	
	public void block() {
		this.blocked = true;
	}
	public void setState(State state) {
		this.state = state;
	}
	
	public int getRow() 			{ return this.row; }
	public int getCol() 			{ return this.col; }
	public boolean isBlocked() 		{ return this.blocked; }
	public State getState() 	{ return this.state; }
	
	public boolean equals(Location loc) {
		if (loc == null)
			return false;
		
		return
			(this.getRow() == loc.getRow()) &&
			(this.getCol() == loc.getCol()) &&
			(this.isBlocked() == loc.isBlocked());
	}
	
	public Location copy() {
		Location copy = new Location(this.row, this.col, this.state);
		
		if (this.isBlocked()) copy.block();
		
		return copy;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
	    int result = 1;
	    result = prime * result + row;
	    result = prime * result + col;
	    return result;
	}
}

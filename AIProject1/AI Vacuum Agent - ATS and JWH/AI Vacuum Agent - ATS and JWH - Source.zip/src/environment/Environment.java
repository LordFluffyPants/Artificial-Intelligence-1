package environment;

import agent.*;

public class Environment {
	
	private Location[][] locations;
	private int height;
	private int width;
	
	public Agent agent;
	private int agentLoc_Row;
	private int agentLoc_Col;
	private int agentScore;
	
	
	public Environment() {
		this.height = -1;
		this.width = -1;
		this.agentScore = 0;
	}
	
	public void loadLocData(int[][] locData) {
		if (locData == null 
				|| locData.length <= 1 
				|| locData[0].length <= 1)
			throw new IllegalArgumentException();
		
		this.height = locData.length;
		this.width = locData[0].length;
		this.locations = new Location[height][width];
		
		for (int row = 0; row < height; ++row) {
			for (int col = 0; col < width; ++col) {
				
				int locCode = locData[row][col];
				Location loc = new Location(row, col, State.UNKNOWN);
				locations[row][col] = loc;
				
				switch (locCode) {
				
					case 0:
						loc.setState(State.CLEAN);
						break;
					
					case 1:
						loc.setState(State.DIRTY);
						break;
					
					case -1:
					default:
						loc.setState(State.BLOCKED);
						loc.block();
				}
			}
		}
	}
	
	public void loadAgent(int agentLoc_Row, int agentLoc_Col, Agent agent) {
		
		if (agentLoc_Row >= this.height || agentLoc_Col >= this.width)
			throw new IllegalArgumentException();
		this.agentLoc_Row = agentLoc_Row;
		this.agentLoc_Col = agentLoc_Col;
		this.agent = agent;
	}
	
	/**
	 * Update method to be called at each time-step. First, it sends the agent a
	 * copy of its current location for processing. Then, the agent returns the next
	 * action it wants to perform. The state of the environment is updated based on
	 * its current state and the next action decided by the agent. At the end of this
	 * method, the agent's score is updated.
	 */
	public void update() {
		
		Location currentAgentLocation = locations[agentLoc_Row][agentLoc_Col];
		Action agentAction = agent.perceive(currentAgentLocation.copy());
		
		switch (agentAction) {
			case MOVE_UP:
			case MOVE_DOWN:
			case MOVE_LEFT:
			case MOVE_RIGHT:
				this.updateAgentLocation(agentAction);
				break;
				
			case VACUUM:
				currentAgentLocation.setState(State.CLEAN);
				break;
				
			case WAIT:
			default:
				break;
		}
		
		this.updateScore(agentAction);
	}
	
	
	/**
	 * Updates the current location of the Agent based on its current location,
	 * its current action, and the boundaries of the environment.
	 * 
	 * @param agentAction The current action of the agent.
	 */
	private void updateAgentLocation(Action agentAction) {
		switch (agentAction) {
			
			case MOVE_UP:
				this.agentLoc_Row = 
					(agentLoc_Row <= 0)? agentLoc_Row:
					(locations[agentLoc_Row - 1][agentLoc_Col].isBlocked())? agentLoc_Row :
					--agentLoc_Row;
				break;
			
			case MOVE_DOWN:
				this.agentLoc_Row = 
					(agentLoc_Row >= height - 1)? agentLoc_Row:
					(locations[agentLoc_Row + 1][agentLoc_Col].isBlocked())? agentLoc_Row :
					++agentLoc_Row;
				break;
			
			case MOVE_LEFT:
				this.agentLoc_Col =
					(agentLoc_Col <= 0)? agentLoc_Col:
					(locations[agentLoc_Row][agentLoc_Col - 1].isBlocked())? agentLoc_Col:
					--agentLoc_Col;
				break;
			
			case MOVE_RIGHT:
				this.agentLoc_Col =
					(agentLoc_Col >= width - 1)? agentLoc_Col:
					(locations[agentLoc_Row][agentLoc_Col + 1].isBlocked())? agentLoc_Col:
					++agentLoc_Col;
				break;
				
			default:
		}
	}
	
	/**
	 * +1 point for each clean square.
	 * -1 point for each movement.
	 * 
	 * @param agentAction The agent's most recent action.
	 */
	private void updateScore(Action agentAction) {
		this.agentScore += this.numCleanSquares();
		
		switch (agentAction) {
			case MOVE_UP:
			case MOVE_DOWN:
			case MOVE_LEFT:
			case MOVE_RIGHT:
				this.agentScore -= 1;
				break;
				
			default:
				break;
		}
	}
	
	public int reportAgentScore() {
		return this.agentScore;
	}
	
	private int numCleanSquares() {
		int num = 0;
		
		for (int row = 0; row < this.height; ++row) {
			for (int col = 0; col < this.width; ++col) {
				if (this.locations[row][col].getState() == State.CLEAN) {
					num += 1;
				}
					
			}
		}
		return num;
	}
	
	public void print() {
		for (int i = 0; i < height; ++i) {
			System.out.print("[Envir]");
			for (int j = 0; j < width; ++j) {
				
				char outChar;
				switch (locations[i][j].getState()) {
					case CLEAN:
						outChar = ' ';
						break;
					case DIRTY:
						outChar = 'D';
						break;
					case BLOCKED:
						outChar = 'X';
						break;
					case UNKNOWN:
					default:
						outChar = '?';
						break;
				}
				
				System.out.print( ((i == this.agentLoc_Row && j == this.agentLoc_Col)? 'R': ' ') );
				
				System.out.print(outChar);
				
			}
			System.out.println();
		}
		System.out.printf("[Agent] Row: %d  Col: %d \n", this.agentLoc_Row, this.agentLoc_Col);
	}
}

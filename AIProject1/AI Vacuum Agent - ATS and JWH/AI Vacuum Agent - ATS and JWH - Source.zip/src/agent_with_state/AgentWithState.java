package agent_with_state;

import agent.Action;
import agent.Agent;
import environment.Location;
import environment.State;

public class AgentWithState extends Agent {

	private int lifeRemaining;
	private Action lastAction;
	private MovementDecisionUnit MDU;
	
	
	public AgentWithState() {
		this.lifeRemaining = Agent.DEFAULT_LIFE_REMAINING;
		this.lastAction = Action.WAIT;
		this.MDU = new MovementDecisionUnit();
	}
	
	public AgentWithState(int lifeAvailable) {
		this.lifeRemaining = lifeAvailable;
	}
	
	@Override
	public Action perceive(Location loc) {
		this.lifeRemaining -= 1;
		
		if (loc.getState() == State.DIRTY) {
			lastAction = Action.VACUUM;
			return Action.VACUUM;
		}
		
		Action a = this.MDU.digestInformation(loc, lastAction);
		lastAction = a;
		return a;
	}

	@Override
	public int lifeRemaining() {
		return this.lifeRemaining;
	}
}

package agent_with_state;

import java.util.ArrayList;
import java.util.Queue;
import java.util.Random;

import agent.Action;
import environment.Location;

@SuppressWarnings("unused")
public class MovementDecisionUnit {

	private Random rand;
	private Action[] moveActions;
	private ArrayList<LocationRecord> visitedLocations;
	private Location lastLocation;
	private Location currentLocation;
	private Action lastAction;
	private ArrayList<Action> nextActionsQueue;
	
	public MovementDecisionUnit() {
		this.nextActionsQueue = new ArrayList<Action>();
		this.visitedLocations = new ArrayList<LocationRecord>();
		this.rand = new Random();
		this.moveActions = new Action[] {
				Action.MOVE_DOWN, 
				Action.MOVE_LEFT, 
				Action.MOVE_RIGHT,
				Action.MOVE_UP
		};
	}

	public Action digestInformation(Location loc, Action lastAction) {
		
		this.lastLocation = currentLocation;
		this.currentLocation = loc;
		this.lastAction = lastAction;
		
		if (!this.visitedLocations.contains(loc)) {
			this.visitedLocations.add(new LocationRecord(loc));
			this.lastAction = moveActions[rand.nextInt(moveActions.length)];
			return this.lastAction;
		}
		
		if (lastLocation.equals(currentLocation) && lastAction != Action.WAIT) {
			this.visitedLocations.get(this.visitedLocations.indexOf(loc)).blockAction(lastAction);
		}
		
		
		ArrayList<Action> temp = this.visitedLocations.get(this.visitedLocations.indexOf(loc)).availableActions();
		this.lastAction = temp.get(rand.nextInt(temp.size()));
		
		return this.lastAction;
	}
}

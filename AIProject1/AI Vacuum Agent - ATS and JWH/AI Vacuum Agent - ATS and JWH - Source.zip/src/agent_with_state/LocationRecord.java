package agent_with_state;

import java.util.ArrayList;

import agent.Action;
import environment.Location;

public class LocationRecord {

	private int row;
	private int col;
	private ArrayList<Action> blockedActions;
	private Action[] movementActions;
	
	public LocationRecord(Location loc) {
		this.row = loc.getRow();
		this.col = loc.getCol();
		this.blockedActions = new ArrayList<Action>();
		this.movementActions = new Action[] {Action.MOVE_DOWN, Action.MOVE_LEFT, Action.MOVE_RIGHT, Action.MOVE_UP};
	}
	
	public void blockAction(Action a) {
		blockedActions.add(a);
	}
	
	public ArrayList<Action> availableActions() {
		ArrayList<Action> out = new ArrayList<Action>();
		
		for (Action a : movementActions) {
			if (!this.blockedActions.contains(a)) {
				out.add(a);
			}
		}
		
		return out;
	}
	
	@Override
	public boolean equals(Object o) {
		if (o instanceof Location) {
			Location l = (Location) o;
			return (this.row == l.getRow() && this.col == l.getCol());
		}
		LocationRecord lr = (LocationRecord) o;
	
		return (this.row == lr.row && this.col == lr.col);
		
	}
}

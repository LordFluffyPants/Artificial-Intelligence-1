package agent;
import environment.Location;

public abstract class Agent {

	public static int DEFAULT_LIFE_REMAINING = 1000;
	
	public abstract Action perceive(Location loc);

	public abstract int lifeRemaining();
	
	
}

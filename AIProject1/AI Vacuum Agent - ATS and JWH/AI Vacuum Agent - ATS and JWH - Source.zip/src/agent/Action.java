package agent;

public enum Action {

	MOVE_LEFT,
	MOVE_UP,
	MOVE_RIGHT,
	MOVE_DOWN,
	VACUUM,
	WAIT
}

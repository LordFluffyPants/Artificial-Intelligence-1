package agent;

import environment.Location;
import java.util.Random;

public class RandomAgent extends Agent {

	private Random rand;
	private Action[] actions;
	private int lifeRemaining;

	public RandomAgent() {
		this.rand = new Random();
		this.actions = Action.values();
		this.lifeRemaining = Agent.DEFAULT_LIFE_REMAINING;
	}
	
	public RandomAgent(int lifeAvailable) {
		this.rand = new Random();
		this.actions = Action.values();
		this.lifeRemaining = lifeAvailable;
	}
	
	@Override
	public Action perceive(Location loc) {
		lifeRemaining-=1;
		return actions[rand.nextInt(actions.length)];
	}

	@Override
	public int lifeRemaining() {
		return this.lifeRemaining;
	}
}

package agent;

import java.util.Random;
import environment.*;

public class SemiRandomAgent extends Agent {

	private Random rand;
	private Action[] actions;
	private int lifeRemaining;
	
	public SemiRandomAgent() {
		this(Agent.DEFAULT_LIFE_REMAINING);
	}
	
	public SemiRandomAgent(int lifeAvailable) {
		this.lifeRemaining = lifeAvailable;
		this.rand = new Random();
		this.actions = new Action[] {
				Action.MOVE_DOWN, 
				Action.MOVE_LEFT, 
				Action.MOVE_RIGHT,
				Action.MOVE_UP
		};
	}
	
	@Override
	public Action perceive(Location loc) {
		this.lifeRemaining -= 1;
		
		if (loc == null)
			return Action.WAIT;
		
		if (loc.getState() == State.DIRTY)
			return Action.VACUUM;
		
		return this.actions[rand.nextInt(this.actions.length)];
	}

	@Override
	public int lifeRemaining() {
		return this.lifeRemaining;
	}

}
